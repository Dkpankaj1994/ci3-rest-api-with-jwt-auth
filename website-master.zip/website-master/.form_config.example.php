<?php
// register the domain at https://www.google.com/recaptcha/admin
// email is disabled currently so this value is also not used
$secret = "--- enter the key ---";

$email_to="--- enter the email to submit to ---";
$cpr_sub="--- enter the email to send cpr stuff to ---";
