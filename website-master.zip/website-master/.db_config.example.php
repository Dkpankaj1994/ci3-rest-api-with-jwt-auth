<?php

// Edit the below values to match the actual details to connect to your
// MySQL DB

$dhost = '';
$dname = '';
$duser = '';
$dpassword = '';

$dsn = "mysql:host={$dhost};dbname={$dname}";

$slacktoken = '';
