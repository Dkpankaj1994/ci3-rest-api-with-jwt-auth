<?php

$SECRET_KEY = '7UuCvU3qe6fcbw7UqSphmrazBBYM5GNe';
