<?php

// Edit the below values to match the actual details to connect to your
// MySQL DB

$dhost = 'mysql';
$dname = 'ambulanc_web';
$duser = 'root';
$dpassword = 'root';

$dsn = "mysql:host={$dhost};dbname={$dname}";

$slacktoken = 'YOUR TOKEN HERE';

?>
