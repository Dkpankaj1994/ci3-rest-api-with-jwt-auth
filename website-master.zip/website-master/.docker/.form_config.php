<?php
// register the domain at https://www.google.com/recaptcha/admin
$secret = "--- enter the key ---";


$email_to="webmaster@rpiambulance.com";
$cpr_sub="cpr@rpiambulance.com";