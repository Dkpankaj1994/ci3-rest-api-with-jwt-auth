angular.module('404Ctrl', []).controller('404Ctrl', ['$scope', '$http', function($scope, $http) {

}]);
