var ctrl_name = 'CoverageDetailsCtrl';
angular.module(ctrl_name, []).controller(ctrl_name, ['$scope', function($scope) {

}]);