var ctrl_name = 'CompatibilityCtrl';
angular.module(ctrl_name, []).controller(ctrl_name, ['$scope', function($scope) {

}]);