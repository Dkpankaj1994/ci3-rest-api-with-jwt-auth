var ctrl_name = 'DevsCtrl';
angular.module(ctrl_name, []).controller(ctrl_name, ['$scope', function($scope) {

}]);